from django.apps import AppConfig


class ShopuserConfig(AppConfig):
    name = 'ShopUser'
