from django.apps import AppConfig


class GuestuserConfig(AppConfig):
    name = 'GuestUser'
